Vending Machine 3.0 
developed by NaVin Enterprises @2018
The program is designed to run on either platform
with ease. The program came about as part of a collaboration
between myself and Nate R. as part of a challenge to create such a thing. 
The user has the ability to simulate a vending machine and the
virtual purchasing style of a machine. It also incorporates a manager
section where the user has the ability to be the manager of the machine.