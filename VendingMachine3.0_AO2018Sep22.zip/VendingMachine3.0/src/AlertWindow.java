// This is our own work by Nate R. Vincent C.
// CST-135 Professor Mneimneh
// September 21, 2018

import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;

public class AlertWindow {

    public static void display(String title, String message) {
        Stage window = new Stage();

        //Blocks of events to let user know something isn't correct. 
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(title);
        window.setResizable(false);
        
        Button closeButton = new Button(message);
        closeButton.setMinSize(300, 100);
        closeButton.setStyle("-fx-font-size: 30");
        closeButton.setOnAction(e -> window.close());

        VBox layout = new VBox(30);
        layout.getChildren().addAll(closeButton);
        layout.setAlignment(Pos.CENTER);

        //Display window and what for it to be properly closed. 
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();}}
