// This is our own work by Nate R. Vincent C.
// CST-135 Professor Mneimneh
// September 21, 2018

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.*;

public class Dispensary extends Inventory {

    Double total = 0.0;

    ObservableList<Drink> drinksList = FXCollections.observableArrayList();
    ObservableList<Candy> candyList = FXCollections.observableArrayList();
    ObservableList<Chips> chipsList = FXCollections.observableArrayList();
    ObservableList<Gum> gumList = FXCollections.observableArrayList();
    ObservableList<Inventory> inventory = FXCollections.observableArrayList();

//No Constructors
    public Dispensary() {}

    public void createDrinks() {

//Products of each type available in Vending Machine
			Drink drink1 = new Drink("Coke", "Coca-Cola", 2.00,"Coke.jpg", 25, "drink1");
			Drink drink2 = new Drink("Coke Zero", "Coca-Cola", 2.00,"coke_zero.jpg", 25, "drink2");
			Drink drink3 = new Drink("Nuka-Cola Quantum", "Nuka-Cola", 3.50,"Fallout4_Nuka_Cola_Quantum.png", 25, "drink3");
			Drink drink4 = new Drink("Nuka-Cola Dark", "Nuka Cola", 1.50,"Nuka-Cola_Dark.png", 25, "drink4");
            inventory.addAll(drink1, drink2, drink3, drink4);}

    public void createCandy() {

			Candy candy1 = new Candy("Peanut Butter Cups", "Reese", 1.0,"reese_pbc.jpg", 25, "candy1");
			Candy candy2 = new Candy("Fancy Lad Snack Cakes ", "Spring Valley", 2.0,"Fallout4_Fancy_lads_snack_cakes.png", 25, "candy2");
			Candy candy3 = new Candy("Sugar Bombs", "Spring Valley", 4.00,"Fallout4_Sugar_Bombs.png", 25, "candy3");
			Candy candy4 = new Candy("Kit Kats", "Nestle", 1.00,"kitkats.jpg", 25,"candy4");
			inventory.addAll(candy1, candy2, candy3, candy4); }

    public void createChips() {

			Chips chip1 = new Chips("Cheetos", "Frito-Lay", 2.00,"cheetos flamin hot.jpg", 25, "chips1");
			Chips chip2 = new Chips("Fritos", "Frito-Lay", 2.00,"fritos chili cheese.png", 25, "chips2");
			Chips chip3 = new Chips("Doritos", "Frito-Lay", 1.25,"doritos cool ranch.png", 25, "chips3");
			Chips chip4 = new Chips ("Potato Crisps", "Spring Valley", 1.00,"Fallout4_Potato_Crisps.png", 25, "chips4");
            inventory.addAll(chip1, chip2, chip3, chip4);}

    public void createGum() {

			Gum gum1 = new Gum("Orbit", "Wrigley's", 1.00,"wintermint.png", 25, "gum1");
			Gum gum2 = new Gum("Orbit", "Wrigley's", 1.00,"strawberry.jpg", 25, "gum2");
			Gum gum3 = new Gum("Orbit", "Wrigley's", 1.00,"orbit-snacks-spearmint.jpg", 25,"gum3");
			Gum gum4 = new Gum("Gum Dropst", "Spring Valley", 1.00, "Fallout4_Gum_drops.png", 25, "gum4");
            inventory.addAll(gum1, gum2, gum3, gum4);}

    public Double total(Double price) {

        total = total + price;

        return total;}

    public ObservableList<Drink> drinksTableView(ObservableList<Inventory> inventory){
        for (Inventory inventory1 : inventory){
            if (inventory1.getProductID().contains("drink")){
                drinksList.add((Drink)inventory1);}}

        Collections.sort(drinksList);
        return drinksList;}

    public ObservableList<Chips> chipsTableView(ObservableList<Inventory> inventory){
        for (Inventory inventory2 : inventory){
            if (inventory2.getProductID().contains("chips")){
                chipsList.add((Chips)inventory2);}}
        
        Collections.sort(chipsList);
        return chipsList;}

    public ObservableList<Candy> candyTableView(ObservableList<Inventory> inventory){
        for (Inventory inventory3 : inventory){
            if (inventory3.getProductID().contains("candy")){
                candyList.add((Candy)inventory3);}}

        Collections.sort(candyList);
        return candyList;}

    public ObservableList<Gum> gumTableView(ObservableList<Inventory> inventory){
        for (Inventory inventory4 : inventory){
            if (inventory4.getProductID().contains("gum")){
                gumList.add((Gum)inventory4);}}

        Collections.sort(gumList);
        return gumList;}

    public static void displayProducts() {}}