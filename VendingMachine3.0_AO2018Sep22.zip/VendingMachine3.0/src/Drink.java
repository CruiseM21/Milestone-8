// This is our own work by Nate R. Vincent C.
// CST-135 Professor Mneimneh
// September 21, 2018

import java.text.DecimalFormat;

//Subclass of Inventory
public class Drink extends Inventory implements Comparable<Drink> {

//Variables
	private String brand;

	
	private static DecimalFormat df1 = new DecimalFormat("#0.00");

//No Constructors
	public Drink() {}

//Constructors
	Drink(String name, String brand, double price, String image, int quantity, String productID) {

		super.setName(name);
		super.setPrice(price);
		super.setBrand(brand);
		super.setImage(image);
		super.setQuantity(quantity);
		super.setProductID(productID);}

//Getters & Setters
	
	public String getName() { return super.getName();}

	public double getPrice() { return super.getPrice();}
	
	public String getBrand() { return super.getBrand(); }

	public String getImage() { return super.getImage(); }

    public int getQuantity() {return super.getQuantity();}
    
    public String getProductID() {return super.getProductID();}

    @Override
	public int compareTo(Drink other) {
		if (getName().toUpperCase().compareTo(other.getName().toUpperCase()) > 0) {
			return 1;
		} else if (getName().toUpperCase().compareTo(other.getName().toUpperCase()) < 0) {
			return -1;
		} else if (getPrice() > other.getPrice()) {
			return 1;
		} else if (getPrice() < other.getPrice()) {
			return -1;
		} else return 0;
	}
	
	@Override
	public String toString() {
		return String.format("%-10s%-20s%-12.2f%-12.2f%-12d%-12.2f%-12b%-12b" + df1, brand, name, price, productID);}}
