// This is our own work by Nate R. Vincent C.
// CST-135 Professor Mneimneh
// September 21, 2018

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class Global_Inventory_Management {

    ObservableList<Inventory> localInventory = FXCollections.observableArrayList();
    private static Scanner sc;
    QuickSort sorter = new QuickSort();

    public ObservableList<Inventory> GlobalInventoryManagement() {

      ObservableList<Inventory> globalInventoryList = FXCollections.observableArrayList();
      String csvFile = "Inventory.csv";
      Inventory[] inventoryArray;

//Get Products for the Inventory
        try {
          sc = new Scanner(new File(csvFile));
          sc.useDelimiter("[,\n]");

//Header Line Skips
         String header = sc.nextLine();

         int j = 0;
         while (sc.hasNextLine()) {
                sc.nextLine();
                j++;}
            sc.close();
            inventoryArray = new Inventory[j];

//New Scanner
            sc = new Scanner(new File(csvFile));
            sc.useDelimiter("[,\n]");

//Header Line Skip
            String header2 = sc.nextLine();

            int i = 0;
            while (sc.hasNextLine()) {
              String nextLine = sc.nextLine();
              String[] lineArray = nextLine.split(",");
              String name = lineArray[0];
              String strPrice = lineArray[1];
              String strQuantity = lineArray[2];
              double price = Double.parseDouble(strPrice);
              int quantity = Integer.parseInt(strQuantity);
              String productID = lineArray[3];

              Inventory inventory = new Inventory(name, price, quantity, productID);
              inventoryArray[i] = inventory;
              i++;}
            
//Recursize Sort Array
            sorter.sort(inventoryArray);
            globalInventoryList.addAll(inventoryArray);}
           catch (Exception e) {
              AlertWindow.display("ERROR", "Errors are present");
              e.printStackTrace();}
           return globalInventoryList;}

public ObservableList<Inventory> readCurrentInventory(ObservableList<Inventory> inventory) {
        String csvFile = "Inventory.csv";

//Stores Products into Temp File
         Inventory[] temp = new Inventory[inventory.size()];
         int i = 0;
         for (Inventory inventoryTemp : inventory) {
            temp[i] = inventoryTemp;
            i++;}
        
//Recursive Sorts into the array
        sorter.sort(temp);

//Clears ObservableList
        inventory.clear();

//ObseravbleList to match Array
        for (Inventory inventoryTemp : temp) {
            inventory.add(inventoryTemp);}

//Inventory File to ObserableFile to update the current inventory
        try {
          sc = new Scanner(new File(csvFile));
          sc.useDelimiter("[,\n]");

          String header = sc.nextLine();

          while (sc.hasNextLine()) {
           String nextLine = sc.nextLine();
           String[] lineArray = nextLine.split(",");
           String name = lineArray[0];
           String strPrice = lineArray[1];
           String strQuantity = lineArray[2];
           double price = Double.parseDouble(strPrice);
           int quantity = Integer.parseInt(strQuantity);
           String productID = lineArray[3];

           Inventory inventory1 = new Inventory(name, price, quantity, productID);
           localInventory.add(inventory1);}}
 
         catch (Exception e) {
            AlertWindow.display("ERROR", "Error with Array");
            e.printStackTrace();}
        
//Compares ProductID to inventory and updates with the changes
        i = 0;
        for (Inventory inventory1 : inventory) {
          for (Inventory inventory2 : localInventory)
            if (inventory1.productID.equals(inventory1.getProductID())) {
               inventory1.setQuantity(inventory1.getQuantity());}
            i++;}
        return inventory;}}

//Recursive Sort by ProductID
class QuickSort {
    Inventory[] globalInventory;
    int length;
    void sort(Inventory[] globalInventoryList) {
        if (globalInventoryList == null || globalInventoryList.length == 0) {
            return;}
        this.globalInventory = globalInventoryList;
        this.length = globalInventoryList.length;
        quickSort(0, length - 1);}
    
    void quickSort(int lowerIndex, int higherIndex) {
        int i = lowerIndex;
        int j = higherIndex;
        String pivot = this.globalInventory[lowerIndex + (higherIndex - lowerIndex) / 2].getName();
        while (i <= j) {
            while (this.globalInventory[i].getName().compareToIgnoreCase(pivot) < 0) {
                i++;}
            while (this.globalInventory[j].getName().compareToIgnoreCase(pivot) > 0) {
                j--;}
            if (i <= j) {
                exchangeNames(i, j);
                i++;
                j--;}}

//QuickSort Recursivley
        if (lowerIndex < j) {
            quickSort(lowerIndex, j);}
        if (i < higherIndex) {
            quickSort(i, higherIndex);}}
    void exchangeNames(int i, int j) {
        Inventory temp = this.globalInventory[i];
        this.globalInventory[i] = this.globalInventory[j];
        this.globalInventory[j] = temp;}}

class RecursiveSearch {
    public static int recursiveSearch(ObservableList<Inventory> list, String key) {
        int low = 0;
        int high = list.size() - 1;
        int mid;

//ObservalList to Temp Product[]
        Inventory[] temp = new Inventory[list.size()];
        int i = 0;
        for (Inventory productTemp : list) {
            temp[i] = productTemp;
            i++;}
        while (low <= high) {
            mid = (low + high) / 2;
            if (temp[mid].getName().compareToIgnoreCase(key) < 0) {
                low = mid + 1;}
        else if (temp[mid].getName().compareToIgnoreCase(key) > 0) {
                high = mid - 1;}
        else {
            writeCallStack(key);
            return mid;}}
        writeCallStack(key);
        return -1;}

    public static void writeCallStack(String key){

//File Header for StackTrace
        final String FILE_HEADER = "Search Stack for Keyword:  " + key + "\n\n";
        FileWriter fileWriter = null;
        try {

//Deletes current inventory before overwriting a new .csv file
        try {
          File file = new File("Search Call Stack.txt");
          file.delete();}
       catch (Exception e) { }
            fileWriter = new FileWriter("Search Stack Results.txt");

//Stack File Header
            fileWriter.append(FILE_HEADER.toString());

//New Product to ObseravleList
                fileWriter.append(Arrays.toString(Thread.currentThread().getStackTrace()));}
         catch (Exception e) {
            AlertWindow.display("ERROR", "Error Writing in the Stack File");}
        finally {
          try {
            fileWriter.flush();
            fileWriter.close();}
            catch (IOException e) {
             AlertWindow.display("ERROR", "Error Closing Stack File");}}}}


