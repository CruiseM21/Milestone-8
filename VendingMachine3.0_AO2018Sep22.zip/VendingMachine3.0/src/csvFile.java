// This is our own work by Nate R. Vincent C.
// CST-135 Professor Mneimneh
// September 21, 2018

import javafx.collections.ObservableList;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

public class csvFile{

//.csv file delimiter
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";

//.csv File Header
    private static final String FILE_HEADER = "Name, Price, Quantity, ProductID";

    public static void writeCsvFile(ObservableList<Inventory> inventory) {
        FileWriter fileWriter = null;
        try {

//Deletes existing inventory before updating
        try {
           File file = new File("Inventory.csv");
           file.delete();}
        catch (Exception e) {}
         fileWriter = new FileWriter("Inventory.csv");

//Write .csv File HEader
            fileWriter.append(FILE_HEADER.toString());

//Line Separator
            fileWriter.append(NEW_LINE_SEPARATOR);

//New Product add to .csv file
      for (Inventory inventory1 : inventory) {
         fileWriter.append(String.valueOf(inventory1.getName()));
         fileWriter.append(COMMA_DELIMITER);
         fileWriter.append(String.valueOf(inventory1.getPrice()));
         fileWriter.append(COMMA_DELIMITER);
         fileWriter.append(String.valueOf(inventory1.getQuantity()));
         fileWriter.append(COMMA_DELIMITER);
         fileWriter.append(String.valueOf(inventory1.getProductID()));
         fileWriter.append(NEW_LINE_SEPARATOR);}}
           
       catch (Exception e) {
             AlertWindow.display("ERROR", "There was an error writing in the .csv file");}
       finally {
         try {
           fileWriter.flush();
           fileWriter.close();}
         catch (IOException e) {
           AlertWindow.display("ERROR", "Error closing the .csv file");}}}}

